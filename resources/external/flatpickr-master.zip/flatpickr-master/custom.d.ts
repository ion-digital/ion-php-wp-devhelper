declare module "autoprefixer-stylus" {
  const t: any;
  export = t;
}
